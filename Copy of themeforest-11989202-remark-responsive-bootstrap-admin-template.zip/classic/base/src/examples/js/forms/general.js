jQuery(document).ready(function() {
  Form.init();
});
